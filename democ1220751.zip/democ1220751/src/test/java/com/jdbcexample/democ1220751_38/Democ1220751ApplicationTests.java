package com.jdbcexample.democ1220751_38;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Democ1220751ApplicationTests {

	@Test
	void contextLoads() {
	}

}
