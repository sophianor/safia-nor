package com.jdbcexample.democ1220751_38;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Democ1220751Application {

	public static void main(String[] args) {
		SpringApplication.run(Democ1220751Application.class, args);
	}

}
